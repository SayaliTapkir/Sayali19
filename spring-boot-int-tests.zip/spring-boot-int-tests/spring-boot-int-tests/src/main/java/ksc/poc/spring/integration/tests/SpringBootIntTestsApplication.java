package ksc.poc.spring.integration.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootIntTestsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootIntTestsApplication.class, args);
	}

}
